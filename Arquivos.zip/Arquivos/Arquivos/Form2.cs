﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form2 : Form
    {
        int opcao = 0;
        public Form2(int op)
        {
            InitializeComponent();
            if (DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714", "cl*24031994")) Console.WriteLine("Conectado");
            else
                Console.WriteLine("Erro de conexão");

            this.WindowState = FormWindowState.Maximized;
            if (op == 1)
            {
                button1.Text = "Salvar";
                opcao = 1;
            }
            else
            {
                button1.Text = "Alterar";
                opcao = 2;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String indicado = "";

            label10.Text = comboBox1.SelectedItem.ToString();
            label11.Text = comboBox2.SelectedItem.ToString();
            label12.Text = comboBox3.SelectedItem.ToString();
            label13.Text = textBox1.Text;
            label14.Text = comboBox4.SelectedItem.ToString();
            label15.Text = comboBox5.SelectedItem.ToString();
            if (radioButton1.Checked) indicado = "Filhote";
            else if (radioButton2.Checked) indicado = "Adulto";
            else if (radioButton3.Checked) indicado = "Sênior";
            label16.Text = indicado;


            MessageBox.Show("Dados salvos com sucesso");

            Produto produto = new Produto(comboBox1.Text, comboBox2.Text, comboBox3.Text, int.Parse(textBox1.Text), comboBox4.Text, comboBox5.Text, indicado);

            if (opcao == 1)
            {

                if (produto.cadastrarProduto())
                    MessageBox.Show("Cadastro realizado com sucesso");

                else
                    MessageBox.Show("Erro no cadastro");
            }

            else
            {
                if (produto.atualizarProduto())
                {
                    MessageBox.Show("Atualização realizada com sucesso");
                }


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Remove(comboBox1.SelectedItem);
            comboBox2.Items.Remove(comboBox2.SelectedItem);
            comboBox3.Items.Remove(comboBox3.SelectedItem);
            textBox1.Clear();
            comboBox4.Items.Remove(comboBox4.SelectedItem);
            comboBox5.Items.Remove(comboBox5.SelectedItem);
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            label15.Text = "";
            label16.Text = "";
            MessageBox.Show("Dados excluídos");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //Produto produto = new Produto(int.Parse(textBox1.Text));

            //{
                //if (opcao == 2)
               // {
                   // if (produto.consultarProduto())
                   // {
                        //MessageBox.Show("Produto já cadastrado");
                   // }

                   // MySqlDataReader r = produto.consultarProduto01();
                   // if (r.Read())
                   // {
                       // comboBox1.Text = r["marca_racao"].ToString();
                       // comboBox2.Text = r["tipo_racao"].ToString();
                       // comboBox3.Text = r["sabor_racao"].ToString();
                       // textBox1.Text = r["cod_prod"].ToString();
                       // comboBox4.Text = r["peso_racao"].ToString();
                       // comboBox5.Text = r["porte_cao"].ToString();
                       //if(radioButton1.Checked) = r ["idade_cao"].ToString();
                        
                   // }

                    //DAO_Conexao.con.Close();//somente fecha depois de retornar
                }
            }
        }
   // }
//}
