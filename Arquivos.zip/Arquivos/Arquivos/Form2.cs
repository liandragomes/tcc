﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String indicado = "";
            
            label10.Text = comboBox1.SelectedItem.ToString();
            label11.Text = comboBox2.SelectedItem.ToString();
            label12.Text = comboBox3.SelectedItem.ToString();
            label13.Text = textBox1.Text;
            label14.Text = comboBox4.SelectedItem.ToString();
            label15.Text = comboBox5.SelectedItem.ToString();
            if (radioButton1.Checked) indicado = "Filhote";
            else if(radioButton2.Checked) indicado = "Adulto";
            else if(radioButton3.Checked) indicado = "Sênior";
            label16.Text = indicado;
            

            MessageBox.Show("Dados salvos com sucesso");


        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Remove(comboBox1.SelectedItem);
            comboBox2.Items.Remove(comboBox2.SelectedItem);
            comboBox3.Items.Remove(comboBox3.SelectedItem);
            textBox1.Clear();
            comboBox4.Items.Remove(comboBox4.SelectedItem);
            comboBox5.Items.Remove(comboBox5.SelectedItem);
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            label15.Text = "";
            label16.Text = "";
            MessageBox.Show("Dados excluídos");

        }
    }
}
