﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arquivos
{
    class Entidade
    {
        private String Nomeent;
        private String CNPJ;
        private int Codent;
        private String Email;
        private String Telefone;
        private String Rua;
        private int Numero;
        private String Bairro;
        private String Complemento;
        private String Cep;
        private String Cidade;
        private String Estado;

        public Entidade(string nomeent, string CNPJ, int codent, string Email, string tel, string rua, int num, string Bairro, string comp, string Cep, string cid, string est)
        {
            //DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714","cl*24031994");
            setNomeent(nomeent);
            setCNPJ(CNPJ);
            setCodent(codent);
            setEmail(Email);
            setTelefone(tel);
            setRua(rua);
            setNumero(num);
            setBairro(Bairro);
            setComplemento(comp);
            setCep(Cep);
            setCidade(cid);
            setEstado(est);
        }

        //public Entidade()

        public Entidade(string nomeent)
        {
            setNomeent(nomeent);
        }

        public void setNomeent(string Nomeent)
        {
            this.Nomeent = Nomeent;
        }

        public String getNome()
        {
            return this.Nomeent;
        }


        public void setCNPJ(string CNPJ)
        {
            this.CNPJ = CNPJ;
        }

        public String getCNPJ()
        {
            return this.CNPJ;
        }

        public void setCodent(int Codent)
        {
            this.Codent = Codent;
        }

        public int getCodEnt()
        {
            return this.Codent;
        }

        public void setEmail(string Email)
        {
            this.Email = Email;
        }

        public String getEmail()
        {
            return this.Email;
        }

        public void setTelefone(string Telefone)
        {
            this.Telefone = Telefone;
        }

        public String getTelefone()
        {
            return this.Telefone;
        }

        public void setRua(string Rua)
        {
            this.Rua = Rua;
        }

        public String getRua()
        {
            return this.Rua;
        }

        public void setNumero(int Numero)
        {
            this.Numero = Numero;
        }

        public int getNumero()
        {
            return this.Numero;
        }

        public void setBairro(string Bairro)
        {
            this.Bairro = Bairro;
        }

        public String getBairro()
        {
            return this.Bairro;
        }

        public void setComplemento(string Complemento)
        {
            this.Complemento = Complemento;
        }

        public String getComplemento()
        {
            return this.Complemento;
        }

        public void setCep(string Cep)
        {
            this.Cep = Cep;
        }

        public String getCep()
        {
            return this.Cep;
        }

       public void setCidade(string Cidade)
        {
            this.Cidade = Cidade;
        }

        public String getCidade()
        {
            return this.Cidade;
        }

        public void setEstado(string Estado)
        {
            this.Estado = Estado;
        }

        public String getEstado()
        {
            return this.Estado;
        }


        public bool cadastrarEntidade()
        {

            bool Ent = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand insere = new MySqlCommand("insert into Entidade_PetLife (nome_ent,cnpj,cod_ent,email,telefone,rua,numero,bairro,complemento,cep,cidade,estado) values('" + Nomeent + "', '" + CNPJ + "', " + Codent + ", '" + Email + "', '" + Telefone + "', '" + Rua + "', " + Numero + ", '" + Bairro + "', '" + Complemento + "', '" + Cep + "', '" + Cidade + "', '" + Estado + "')", DAO_Conexao.con);
                insere.ExecuteNonQuery();
                Ent = true;
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return Ent;
        }

        public bool consultarEntidade()
        {
            bool cons = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("select * from Entidade_PetLife where nome_ent = '" + Nomeent + "'", DAO_Conexao.con);
                MySqlDataReader resultado = consulta.ExecuteReader();
                if (resultado.Read())
                {
                    cons = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return cons;
        }

        public bool atualizarEntidade()
        {
            bool exc = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualiza = new MySqlCommand("update Entidade_PetLife set nome_ent = '" + Nomeent + "', cnpj = '" + CNPJ + "', cod_ent = " + Codent + ", email = '" + Email + "', telefone = '" + Telefone + "', rua = '" + Rua + "', numero = " + Numero + ", bairro = '" + Bairro + "', complemento = '" + Complemento + "', cep = '" + Cep +"', cidade = '" + Cidade + "', estado = '" + Estado + "' where nome_ent = '" + Nomeent + "'", DAO_Conexao.con); ;
                atualiza.ExecuteNonQuery();
                exc = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return exc;
        }

        public MySqlDataReader consultarEntidade01()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("select * from Entidade_PetLife " + "where nome_ent='" + Nomeent + "'", DAO_Conexao.con);
                resultado = consulta.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                //DAO_Conexao.con.Close();
                //não pode fechar aqui senão não retorna nada  
            }
            return resultado;
        }
    }
}

