﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Arquivos
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
            if (DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714", "cl*24031994")) Console.WriteLine("Conectado");
            else
                Console.WriteLine("Erro de conexão");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label6.Text = textBox1.Text;
            label7.Text = maskedTextBox2.Text;
            label8.Text = maskedTextBox1.Text;

            if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Código da venda é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (maskedTextBox2.Text == String.Empty)
            {
                MessageBox.Show("Data da venda é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (maskedTextBox1.Text == String.Empty)
            {
                MessageBox.Show("CPF do cliente é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            String forma = "";
            if (radioButton1.Checked) forma = "Boleto";
            else if (radioButton2.Checked) forma = "Cartão de débito";

            label11.Text = forma;

            MessageBox.Show("Dados salvos com sucesso");

            Venda venda = new Venda(int.Parse(textBox1.Text), maskedTextBox2.Text, maskedTextBox1.Text, forma,textBox2.Text);
           // if (opcao == 1)
            {
                if (venda.cadastrarVenda())
                    MessageBox.Show("Cadastro realizado com sucesso");

                else
                    MessageBox.Show("Erro no cadastro");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            textBox2.Clear();
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label11.Text = "";
            MessageBox.Show("Dados excluídos com sucesso");
        }
    }
}
