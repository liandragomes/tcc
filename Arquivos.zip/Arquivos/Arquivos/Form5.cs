﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form5 : Form
    {
        Double Calcular = 0;
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Calcular = Double.Parse(textBox3.Text) * Double.Parse(textBox4.Text);
            textBox5.Text = Calcular.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label8.Text = textBox1.Text;
            label9.Text = textBox2.Text;
            label10.Text = textBox3.Text;
            label11.Text = textBox4.Text;
            label12.Text = textBox5.Text;

            if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Código do produto é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox2.Text == String.Empty)
            {
                MessageBox.Show("Código da venda é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox3.Text == String.Empty)
           {
                MessageBox.Show("Quantidade vendida é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox4.Text == String.Empty)
            {
                MessageBox.Show("Valor unitário é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox5.Text == String.Empty)
            {
                MessageBox.Show("Valor total é de preenchimento obrigatório, por favor clique no botão calcular", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox1.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox2.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox3.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox4.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox5.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            label8.Text = "";
            label9.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
            MessageBox.Show("Dados excluídos");
        }

    }
}

