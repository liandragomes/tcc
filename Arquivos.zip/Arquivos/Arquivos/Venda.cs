﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arquivos
{
    class Venda
    {
        private int Codv;
        private String Datav;
        private String CPF;
        private String Forma;
        private String Numc;

        public Venda(int codv, string datav, string cpf, string forma, string numc)
        {
            //DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714","cl*24031994");
            setCodv(codv);
            setDatav(datav);
            setCPF(cpf);
            setForma(forma);
            setNumc(numc);
        }

        public void setCodv(int Codv)
        {
            this.Codv = Codv;
        }

        public int getCodv()
        {
            return this.Codv;
        }

        public void setDatav(String Datav)
        {
            this.Datav = Datav;
        }

        public String getDatav()
        {
            return this.Datav;
        }

        public void setCPF(String CPF)
        {
            this.CPF = CPF;
        }

        public String getCPF()
        {
            return this.CPF;
        }

        public void setForma(String Forma)
        {
            this.Forma = Forma;
        }

        public String getForma()
        {
            return this.Forma;
        }

        public void setNumc(String Numc)
        {
            this.Numc = Numc;
        }

        public String getNumc()
        {
            return this.Numc;
        }

        public bool cadastrarVenda()
        {

            bool Vend = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand insere = new MySqlCommand("insert into Venda_PetLife (cod_venda,data_venda,cpf,forma_pagamento,numero_cartao) values(" + Codv + ", '" + Datav + "', '" + CPF + "', '" + Forma + "', '" + Numc + "') foreign key (cpf) references Cliente_PetLife(cpf)", DAO_Conexao.con);
                insere.ExecuteNonQuery();
                Vend = true;
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return Vend;
        }



    }
}
