﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arquivos
{
    class Fornecedor
    {
        private String Nomeemp;
        private String CNPJ;
        private int CodFornec;
        private String Email;
        private String Telefone;
        private String Rua;
        private int Numero;
        private String Cep;
        private String Bairro;
        private String Complemento;
        private String Cidade;
        private String Estado;

        public Fornecedor(string nomeemp, string CNPJ, int codfornec, string Email, string tel, string rua, int num, string Cep, string Bairro, string comp, string cid, string est)
        {
            //DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714","cl*24031994");
            setNomeemp(nomeemp);
            setCNPJ(CNPJ);
            setCodFornec(codfornec);
            setEmail(Email);
            setTelefone(tel);
            setRua(rua);
            setNumero(num);
            setCep(Cep);
            setBairro(Bairro);
            setComplemento(comp);
            setCidade(cid);
            setEstado(est);
        }

        //public Fornecedor()

        public Fornecedor(string nomeemp)
        {
            setNomeemp(nomeemp);
        }


        public void setNomeemp(string Nomeemp)
        {
            this.Nomeemp = Nomeemp;
        }

        public String getNome()
        {
            return this.Nomeemp;
        }


        public void setCNPJ(string CNPJ)
        {
            this.CNPJ = CNPJ;
        }

        public String getCNPJ()
        {
            return this.CNPJ;
        }

        public void setCodFornec(int CodFornec)
        {
            this.CodFornec = CodFornec;
        }

        public int getCodFornec()
        {
            return this.CodFornec;
        }

        public void setEmail(string Email)
        {
            this.Email = Email;
        }

        public String getEmail()
        {
            return this.Email;
        }

        public void setTelefone(string Telefone)
        {
            this.Telefone = Telefone;
        }

        public String getTelefone()
        {
            return this.Telefone;
        }

        public void setRua(string Rua)
        {
            this.Rua = Rua;
        }

        public String getRua()
        {
            return this.Rua;
        }

        public void setNumero(int Numero)
        {
            this.Numero = Numero;
        }

        public int getNumero()
        {
            return this.Numero;
        }

        public void setCep(string Cep)
        {
            this.Cep = Cep;
        }

        public String getCep()
        {
            return this.Cep;
        }

        public void setBairro(string Bairro)
        {
            this.Bairro = Bairro;
        }

        public String getBairro()
        {
            return this.Bairro;
        }

        public void setComplemento(string Complemento)
        {
            this.Complemento = Complemento;
        }

        public String getComplemento()
        {
            return this.Complemento;
        }

        public void setCidade(string Cidade)
        {
            this.Cidade = Cidade;
        }

        public String getCidade()
        {
            return this.Cidade;
        }

        public void setEstado(string Estado)
        {
            this.Estado = Estado;
        }

        public String getEstado()
        {
            return this.Estado;
        }


        public bool cadastrarFornecedor()
        { 

        bool Forn = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand insere = new MySqlCommand("insert into Fornecedor_PetLife (nome_emp,cnpj,cod_fornec,email,telefone,rua,numero,cep,bairro,complemento,cidade,estado) values('" + Nomeemp + "', '" + CNPJ + "', " + CodFornec + ", '" + Email + "', '" + Telefone + "', '" + Rua + "', " + Numero + ", '" + Cep + "', '" + Bairro + "', '" + Complemento + "', '" + Cidade + "', '" + Estado + "')", DAO_Conexao.con);
                insere.ExecuteNonQuery();
                Forn = true;
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return Forn;
        }

        public bool consultarFornecedor()
        {
            bool cons = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("select * from Fornecedor_PetLife where nome_emp = '" + Nomeemp + "'", DAO_Conexao.con);
                MySqlDataReader resultado = consulta.ExecuteReader();
                if (resultado.Read())
                {
                    cons = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return cons;
        }

        public bool atualizarFornecedor()
        {
            bool exc = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualiza = new MySqlCommand("update Fornecedor_PetLife set nome_emp = '" + Nomeemp + "', cnpj = '" + CNPJ + "', cod_fornec = " + CodFornec + ", email = '" + Email + "', telefone = '" + Telefone + "', rua = '" + Rua + "', numero = " + Numero + ", cep = '" + Cep + "', bairro = '" + Bairro + "', complemento = '" + Complemento + "', cidade = '" + Cidade+ "', estado = '" + Estado + "' where nome_emp = '" + Nomeemp + "'", DAO_Conexao.con); ;
                atualiza.ExecuteNonQuery();
                exc = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return exc;
        }

        public MySqlDataReader consultarFornecedor01()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("select * from Fornecedor_PetLife " + "where nome_emp='" + Nomeemp + "'", DAO_Conexao.con);
                resultado = consulta.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                //DAO_Conexao.con.Close();
                //não pode fechar aqui senão não retorna nada  
            }
            return resultado;
        }
    }
}
