﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form6 : Form
    {
        Double Calcular = 0, Calcular1 = 0, Calcular2 = 0, Calcular3 = 0;

        private void button3_Click(object sender, EventArgs e)
        {
            Calcular2 = double.Parse(textBox3.Text) - double.Parse(textBox6.Text);
            textBox9.Text = Calcular2.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Calcular3 = double.Parse(textBox9.Text) * double.Parse(textBox10.Text);
            textBox11.Text = Calcular3.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label14.Text = textBox1.Text;
            label15.Text = maskedTextBox1.Text;
            label16.Text = textBox9.Text;
            label17.Text = textBox10.Text;
            label18.Text = textBox11.Text;


            if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Código do produto é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }

            else if(maskedTextBox1.Text == String.Empty)
            {
                MessageBox.Show("Data é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if(textBox3.Text == String.Empty)
            {
                MessageBox.Show("Quantidade comprada é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if(textBox4.Text == String.Empty)
            {
                MessageBox.Show("Valor unitário da compra é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if(textBox5.Text == String.Empty)
            {
                MessageBox.Show("Valor total da compra é de preenchimento obrigatório, por favor clique no botão calcular", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox6.Text == String.Empty)
            {
                MessageBox.Show("Quantidade vendida é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if(textBox7.Text == String.Empty)
            {
                MessageBox.Show("Valor unitário da venda é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox8.Text == String.Empty)
            {
                MessageBox.Show("Valor total da venda é de preenchimento obrigatório, por favor clique no botão calcular", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox9.Text == String.Empty)
            {
                MessageBox.Show("Quantidade final é de preenchimento obrigatório, por favor clique no botão calcular", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if(textBox10.Text == String.Empty)
           {
                MessageBox.Show("Valor unitário do estoque final é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if(textBox11.Text == String.Empty)
           {
                MessageBox.Show("Valor total do estoque final é de preenchimento obrigatório, por favor clique no botão calcular", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }



            else if(textBox1.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(maskedTextBox1.Text != null)
           {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox3.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox4.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox5.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox6.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox7.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox8.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox9.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox10.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if(textBox11.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            maskedTextBox1.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            label14.Text = "";
            label15.Text = "";
            label16.Text = "";
            label17.Text = "";
            label18.Text = "";
            MessageBox.Show("Dados excluídos");
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Calcular1 = double.Parse(textBox6.Text) * double.Parse(textBox7.Text);
            textBox8.Text = Calcular1.ToString();
        }

        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Calcular = double.Parse(textBox3.Text) * double.Parse(textBox4.Text);
            textBox5.Text = Calcular.ToString();
        }
    }
}
