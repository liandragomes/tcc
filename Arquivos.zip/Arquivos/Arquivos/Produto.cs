﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arquivos
{
    class Produto
    {
        private String Marca;
        private String Tipo;
        private String Sabor;
        private int CodProd;
        private String Peso;
        private String Porte;
        private String Indicada;

        public Produto(string marca, string tipo, string sabor, int codprod, string peso, string porte, string indicada)
        {
            //DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714","cl*24031994");
            setMarca(marca);
            setTipo(tipo);
            setSabor(sabor);
            setCodProd(codprod);
            setPeso(peso);
            setPorte(porte);
            setIndicada(indicada);

        }

        //public Produto()

        public Produto(int codprod)
        {
            setCodProd(codprod);
        }


        public void setMarca(string Marca)
        {
            this.Marca = Marca;
        }

        public String getMarca()
        {
            return this.Marca;
        }

        public void setTipo(string Tipo)
        {
            this.Tipo = Tipo;
        }

        public String getTipo()
        {
            return this.Tipo;
        }

        public void setSabor(string Sabor)
        {
            this.Sabor = Sabor;
        }

        public String getSabor()
        {
            return this.Sabor;
        }

        public void setCodProd(int CodProd)
        {
            this.CodProd = CodProd;
        }

        public int getCodProd()
        {
            return this.CodProd;
        }

        public void setPeso(string Peso)
        {
            this.Peso = Peso;
        }

        public String getPeso()
        {
            return this.Peso;
        }

        public void setPorte(string Porte)
        {
            this.Porte = Porte;
        }

        public String getPorte()
        {
            return this.Porte;
        }

        public void setIndicada(string Indicada)
        {
            this.Indicada = Indicada;
        }

        public String getIndicada()
        {
            return this.Indicada;
        }

        public bool cadastrarProduto()
        {

            bool Prod = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand insere = new MySqlCommand("insert into Produto_PetLife (marca_racao,tipo_racao,sabor_racao,cod_prod,peso_racao,porte_cao,idade_cao) values('" + Marca + "', '" + Tipo + "', '" + Sabor + "', " + CodProd + ", '" + Peso + "', '" + Porte + "', '" + Indicada + "')", DAO_Conexao.con);
                insere.ExecuteNonQuery();
                Prod = true;
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return Prod;
        }

        public bool consultarProduto()
        {
            bool cons = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("select * from Produto_PetLife where cod_prod = " + CodProd + "", DAO_Conexao.con);
                MySqlDataReader resultado = consulta.ExecuteReader();
                if (resultado.Read())
                {
                    cons = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return cons;
        }

        public bool atualizarProduto()
        {
            bool exc = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualiza = new MySqlCommand("update Produto_PetLife set marca_racao = '" + Marca + "', tipo_racao = '" + Tipo + "', sabor_racao = '" + Sabor + "', cod_prod = " + CodProd + ", peso_racao = '" + Peso + "', porte_cao = '" + Porte + "', idade_cao = '" + Indicada + "' where cod_prod = " + CodProd + "", DAO_Conexao.con); ;
                atualiza.ExecuteNonQuery();
                exc = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return exc;
        }

        public MySqlDataReader consultarProduto01()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("select * from Produto_PetLife " + "cod_prod = " + CodProd + "", DAO_Conexao.con);
                resultado = consulta.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                //DAO_Conexao.con.Close();
                //não pode fechar aqui senão não retorna nada  
            }
            return resultado;
        }
    }
}

    

