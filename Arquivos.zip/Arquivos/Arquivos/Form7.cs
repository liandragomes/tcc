﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form7 : Form
    {
        int opcao = 0;
        public Form7(int op)
        {

            InitializeComponent();
            if (DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714", "cl*24031994")) Console.WriteLine("Conectado");
            else
                Console.WriteLine("Erro de conexão");

            this.WindowState = FormWindowState.Maximized;
            if (op == 1)
            {
                button1.Text = "Salvar";
                opcao = 1;
            }
            else
            {
                button1.Text = "Alterar";
                opcao = 2;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label12.Text = textBox2.Text;
            label13.Text = maskedTextBox1.Text;
            label14.Text = textBox1.Text;


            if (textBox2.Text == String.Empty)
            {
                MessageBox.Show("Nome da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }

            else if (maskedTextBox1.Text == String.Empty)
            {
                MessageBox.Show("CNPJ da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }


            else if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Código da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }

            else if (textBox4.Text == String.Empty)
            {
                MessageBox.Show("E-mail da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (maskedTextBox2.Text == String.Empty)
            {
                MessageBox.Show("Telefone da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox6.Text == String.Empty)
            {
                MessageBox.Show("A rua da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox7.Text == String.Empty)
            {
                MessageBox.Show("O número do endereço da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox8.Text == String.Empty)
            {
                MessageBox.Show("O bairro da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (maskedTextBox3.Text == String.Empty)
            {
                MessageBox.Show("O CEP da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (textBox11.Text == String.Empty)
            {
                MessageBox.Show("A cidade da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox12.Text == String.Empty)
            {
                MessageBox.Show("O Estado da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


            else if (textBox2.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (maskedTextBox1.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }

            else if (textBox1.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox4.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (maskedTextBox2.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox6.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox7.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox8.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (maskedTextBox3.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox11.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox12.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }

            Entidade entidade = new Entidade(textBox2.Text, maskedTextBox1.Text, int.Parse(textBox1.Text), textBox4.Text, maskedTextBox2.Text, textBox6.Text, int.Parse(textBox7.Text), textBox8.Text, textBox9.Text, maskedTextBox3.Text, textBox11.Text, textBox12.Text);
            if (opcao == 1)
            {

                if (entidade.cadastrarEntidade())
                    MessageBox.Show("Cadastro realizado com sucesso");

                else
                    MessageBox.Show("Erro no cadastro");

            }

            else
            {
                if (entidade.atualizarEntidade())
                {
                    MessageBox.Show("Atualização realizada com sucesso");
                }


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            textBox2.Clear();
            maskedTextBox1.Clear();
            textBox1.Clear();
            textBox4.Clear();
            maskedTextBox2.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            maskedTextBox3.Clear();
            textBox11.Clear();
            textBox12.Clear();
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            MessageBox.Show("Dados excluídos");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Entidade entidade = new Entidade(textBox2.Text);

            {
                if (opcao == 2)
                {
                    if (entidade.consultarEntidade())
                    {
                        MessageBox.Show("Entidade já cadastrada");
                    }

                    MySqlDataReader r = entidade.consultarEntidade01();
                    if (r.Read())
                    {
                        textBox2.Text = r["nome_ent"].ToString();
                        maskedTextBox1.Text = r["cnpj"].ToString();
                        textBox1.Text = r["cod_ent"].ToString();
                        textBox4.Text = r["email"].ToString();
                        maskedTextBox2.Text = r["telefone"].ToString();
                        textBox6.Text = r["rua"].ToString();
                        textBox7.Text = r["numero"].ToString();
                        textBox8.Text = r["bairro"].ToString();
                        textBox9.Text = r["complemento"].ToString();
                        maskedTextBox3.Text = r["cep"].ToString();

                        textBox11.Text = r["cidade"].ToString();
                        textBox12.Text = r["estado"].ToString();
                    }

                    DAO_Conexao.con.Close();//somente fecha depois de retornar
                }
            }
        }
    }
}
