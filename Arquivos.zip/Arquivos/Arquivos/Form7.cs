﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label12.Text = textBox1.Text;
            label13.Text = textBox2.Text;
            label14.Text = textBox3.Text;
            


            if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Código da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }

            else if (textBox2.Text == String.Empty)
            {
                MessageBox.Show("Nome da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox3.Text == String.Empty)
            {
                MessageBox.Show("CNPJ da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox4.Text == String.Empty)
            {
                MessageBox.Show("E-mail da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox5.Text == String.Empty)
            {
                MessageBox.Show("Telefone da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox6.Text == String.Empty)
            {
                MessageBox.Show("A rua da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox7.Text == String.Empty)
            {
                MessageBox.Show("O número do endereço da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox8.Text == String.Empty)
            {
                MessageBox.Show("O bairro da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox10.Text == String.Empty)
            {
                MessageBox.Show("O CEP da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (textBox11.Text == String.Empty)
            {
                MessageBox.Show("A cidade da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
            else if (textBox12.Text == String.Empty)
            {
                MessageBox.Show("O Estado da entidade é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }



            else if (textBox1.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox2.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox3.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox4.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox5.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox6.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox7.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox8.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox10.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox11.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
            else if (textBox12.Text != null)
            {
                MessageBox.Show("Salvo com sucesso");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            MessageBox.Show("Dados excluídos");
        }
    }
}
