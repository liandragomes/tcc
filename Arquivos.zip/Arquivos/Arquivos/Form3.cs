﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form3 : Form
    {
        Double calc = 0;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            calc = Double.Parse(textBox6.Text) * Double.Parse(textBox7.Text);
            textBox8.Text = calc.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label11.Text = textBox2.Text;
            label12.Text = textBox3.Text;
            label13.Text = textBox4.Text;
            label14.Text = textBox6.Text;
            label15.Text = textBox8.Text;

            if (maskedTextBox1.Text == String.Empty)
            {
                MessageBox.Show("Data é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox2.Text == String.Empty)
            {
                MessageBox.Show("Código do produto é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox3.Text == String.Empty)
            {
                MessageBox.Show("Código do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox4.Text == String.Empty)
            {
                MessageBox.Show("Código da compra é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox6.Text == String.Empty)
            {
                MessageBox.Show("Quantidade comprada é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox7.Text == String.Empty)
            {
                MessageBox.Show("Valor unitário é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(textBox8.Text == String.Empty)
            {
                MessageBox.Show("Clique no botão calcular para saber o valor total, que é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(maskedTextBox1.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox2.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox3.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox4.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox6.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox7.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if(textBox8.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            label11.Text = "";
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            label15.Text = "";
            MessageBox.Show("Dados excluídos com sucesso");

        }
    }
}
