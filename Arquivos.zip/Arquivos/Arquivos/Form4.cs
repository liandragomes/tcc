﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form4 : Form
    {
        int opcao = 0;

        public Form4(int op)
        {
            InitializeComponent();
            if (DAO_Conexao.getConexao("143.106.241.3", "cl12714", "cl12714", "cl*24031994")) Console.WriteLine("Conectado");
            else
                Console.WriteLine("Erro de conexão");

            this.WindowState = FormWindowState.Maximized;
            if (op == 1)
            {
                button1.Text = "Salvar";
                opcao = 1;
            }
            else
            {
                button1.Text = "Alterar";
                opcao = 2;
            }
        }



        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label15.Text = textBox1.Text;
            label16.Text = maskedTextBox1.Text;
            label17.Text = textBox3.Text;


            if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Nome da empresa é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (maskedTextBox1.Text == String.Empty)
            {
                MessageBox.Show("CNPJ da empresa é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (textBox3.Text == String.Empty)
            {
                MessageBox.Show("Código do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (textBox4.Text == String.Empty)
            {
                MessageBox.Show("E-mail para contato é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (maskedTextBox3.Text == String.Empty)
            {
                MessageBox.Show("Telefone para contato é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox6.Text == String.Empty)
            {
                MessageBox.Show("Rua ou avenida do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox7.Text == String.Empty)
            {
                MessageBox.Show("O n° do endereço do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (maskedTextBox2.Text == String.Empty)
            {
                MessageBox.Show("O CEP do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox9.Text == String.Empty)
            {
                MessageBox.Show("O Bairro do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox11.Text == String.Empty)
            {
                MessageBox.Show("A cidade do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox12.Text == String.Empty)
            {
                MessageBox.Show("O estado do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (textBox1.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (maskedTextBox1.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox3.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox4.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (maskedTextBox3.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox6.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox7.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (maskedTextBox2.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox9.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox11.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox12.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }

            Fornecedor fornecedor = new Fornecedor(textBox1.Text, maskedTextBox1.Text, int.Parse(textBox3.Text), textBox4.Text, maskedTextBox3.Text, textBox6.Text, int.Parse(textBox7.Text), maskedTextBox2.Text, textBox9.Text, textBox10.Text, textBox11.Text, textBox12.Text);
            if (opcao == 1)
            {
                if (fornecedor.cadastrarFornecedor())
                    MessageBox.Show("Cadastro realizado com sucesso");

                else
                    MessageBox.Show("Erro no cadastro");
            }

            else
            {
                if (fornecedor.atualizarFornecedor())
                {
                    MessageBox.Show("Atualização realizada com sucesso");
                }


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            maskedTextBox1.Clear();
            textBox3.Clear();
            textBox4.Clear();
            maskedTextBox3.Clear();
            textBox6.Clear();
            textBox7.Clear();
            maskedTextBox2.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            label15.Text = "";
            label16.Text = "";
            label17.Text = "";
            MessageBox.Show("Dados excluídos com sucesso");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Fornecedor fornecedor = new Fornecedor(textBox1.Text);

            {
                if (opcao == 2)
                {
                    if (fornecedor.consultarFornecedor())
                    {
                        MessageBox.Show("Empresa já cadastrada");
                    }

                    MySqlDataReader r = fornecedor.consultarFornecedor01();
                    if (r.Read())
                    {
                        textBox1.Text = r["nome_emp"].ToString();
                        maskedTextBox1.Text = r["cnpj"].ToString();
                        textBox3.Text = r["cod_fornec"].ToString();
                        textBox4.Text = r["email"].ToString();
                        maskedTextBox3.Text = r["telefone"].ToString();
                        textBox6.Text = r["rua"].ToString();
                        textBox7.Text = r["numero"].ToString();
                        maskedTextBox2.Text = r["cep"].ToString();
                        textBox9.Text = r["bairro"].ToString();
                        textBox10.Text = r["complemento"].ToString();
                        textBox11.Text = r["cidade"].ToString();
                        textBox12.Text = r["estado"].ToString();
                    }

                    DAO_Conexao.con.Close();//somente fecha depois de retornar
                }
            }
        }
    }
}
