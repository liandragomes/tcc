﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arquivos
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String forma = "";
            label7.Text = maskedTextBox1.Text;
            int.Parse(comboBox2.SelectedItem.ToString());
            label8.Text = comboBox2.SelectedItem.ToString();
            label9.Text = comboBox1.SelectedItem.ToString();
            if (radioButton1.Checked) forma = "Boleto";
            else if (radioButton2.Checked) forma = "Cartão de débito";
            
            label10.Text = forma;

            MessageBox.Show("Dados salvos com sucesso");

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            comboBox2.Items.Remove(comboBox2.SelectedItem);
            comboBox1.Items.Remove(comboBox1.SelectedItem);
            textBox2.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            textBox1.Clear();
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
            label10.Text = "";
            MessageBox.Show("Dados excluídos com sucesso");
        }
    }
}
