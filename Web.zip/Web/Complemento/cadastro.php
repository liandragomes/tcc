<?php

$nome = $_POST["nome"];
$cpf = $_POST["cpf"];
$datanascimento = $_POST["datanascimento"];
$sexo = $_POST["sexo"];
$email = $_POST["email"];
$tel = $_POST["tel"];
$cep = $_POST["cep"];
$rua = $_POST["rua"];
$numero = $_POST["numero"];
$bairro = $_POST["bairro"];
$cidade = $_POST["cidade"];
$estado = $_POST["estado"];

if($nome != "" || $cpf != ""|| $datanascimento != "" || $sexo != ""|| $email != "" || $tel != "" || $cep != "" || $rua != "" ||$numero != "" || $bairro != "" | $cidade != "" || $estado != ""){
echo "Você efetuou seu cadastro com sucesso."; 
echo "<br><br>";
echo "Veja o que foi preenchido:";
echo "<br><br>";
echo "Nome = " . $nome . "<br>";
echo "CPF = " . $cpf . "<br>";
echo "Data de nascimento = " . $datanascimento . "<br>";
echo "Sexo = " . $sexo . "<br>";
echo "E-mail = " . $email . "<br>";
echo "Telefone = " . $tel . "<br>";
echo "CEP = " . $cep . "<br>";
echo "Rua ou Avenida = " . $rua . "<br>";
echo "Número = " . $numero . "<br>";
echo "Bairro = " . $bairro . "<br>";
echo "Cidade = " . $cidade . "<br>";
echo "Estado = " . $estado . "<br>";
}
?>

<html>
<head>
<title>Cadastro</title>
<style>
</style>
</head>
<body>
<br><br>
<a href="../indexbootstrap.html" >Clique aqui</a> , assim você será direcionado para outra página. 
</body>	
</html>
