<?php

$email = $_POST["email"];
$password = $_POST["password"];

if($email != "" || $password != ""){
echo "Você preencheu corretamente seu e-mail e senha."; 
}

?>

<html>
<head>
<title>Login</title>
<style>
</style>
</head>
<body>
<br><br>
<a href="../indexbootstrap.html" >Clique aqui</a> , assim você será direcionado para outra página. 
</body>	
</html>
