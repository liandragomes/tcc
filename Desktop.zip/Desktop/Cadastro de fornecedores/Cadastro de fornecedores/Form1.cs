﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_de_fornecedores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label15.Text = textBox1.Text;
            label16.Text = textBox2.Text;
            label17.Text = textBox3.Text;

            if (textBox1.Text ==String.Empty)
            {
                MessageBox.Show("Nome da empresa é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox2.Text == String.Empty)
            {
                MessageBox.Show("CNPJ da empresa é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox3.Text == String.Empty)
            {
                MessageBox.Show("Código do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox4.Text == String.Empty)
            {
                MessageBox.Show("E-mail para contato é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox5.Text == String.Empty)
            {
                MessageBox.Show("Telefone para contato é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox6.Text == String.Empty)
            {
                MessageBox.Show("Rua ou avenida do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox7.Text == String.Empty)
            {
                MessageBox.Show("O n° do endereço do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox8.Text == String.Empty)
            {
                MessageBox.Show("O CEP do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox9.Text == String.Empty)
            {
                MessageBox.Show("O Bairro do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox11.Text == String.Empty)
            {
                MessageBox.Show("A cidade do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox12.Text == String.Empty)
            {
                MessageBox.Show("O estado do fornecedor é de preenchimento obrigatório", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (textBox1.Text!=null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox2.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox3.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox4.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox5.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox6.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox7.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox8.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox9.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox11.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }
            else if (textBox12.Text != null)
            {
                MessageBox.Show("Dados salvos com sucesso");
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            MessageBox.Show("Dados excluídos com sucesso");
        }
    }
    }

